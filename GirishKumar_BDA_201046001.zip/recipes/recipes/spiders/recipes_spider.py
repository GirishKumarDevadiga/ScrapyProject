#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 27 17:58:03 2020

@author: girish
"""
import scrapy
from ..items import RecipesItem

class RecipesSpider(scrapy.Spider):
    name = 'recipes'
    start_urls = [
                   'https://www.kindmeal.my/recipes.htm'
                 ]
    
    # fetching the required html data
    def parse(self, response):
       # declaring the items variable and chef_recipe_data variable to hold the data for yield
       items = RecipesItem()
       chef_recipe_data = [] 

       # Fetchinh the 12 chef and recipe data per page and pushing the same to chef_recipe_data list 
       for i in range(0, 12):
            items = {}
            try:
                # chef_name stores the chef name obtained from html 
                chef_name = response.css('div#menu_box_'+str(i)+' a::text').get()
                # chef_profile_img stores the chef profile image obtained from html 
                chef_profile_img = 'https://www.kindmeal.my/' + response.css('div#menu_box_'+str(i)+' a img::attr(src)').get()
                # recipe_name stores the recipe name obtained from html 
                recipe_name = response.css('div#menu_box_'+str(i)+' div.recipe_label::text').get()
                # recipe_link stores the recipe link obtained from html 
                recipe_link = response.css('div#menu_box_'+str(i)+' div.imagecrop_menu a::attr(href)').get()

                # copying the data to items variable
                items['chefName'] = chef_name
                items['chefProfileImage'] = chef_profile_img
                items['recipeName'] = recipe_name
                items['recipeLink'] = recipe_link
                #appending the items to chef_recipe_data list 
                chef_recipe_data.append(items)
                
            except:
                pass
 
       # chef_recipe_data  yield
       yield {'data': chef_recipe_data }  
       
       # checking more than 1 link present in div attribute and fetching the next link 
       if(len(response.css('div.button_grey::attr(onclick)').getall())> 1):
           next_page = response.css('div.button_grey::attr(onclick)').getall()[1].split("'")[1]
       else:    
           next_page = response.css('div.button_grey::attr(onclick)').get().split("'")[1]
       
       # checking next page is None or not, if not None request is sent again and responses are yieled after fetching html data
       if next_page is not None:
           yield response.follow(next_page, callback = self.parse)
       
       
