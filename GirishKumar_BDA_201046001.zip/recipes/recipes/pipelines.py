# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import sqlite3


class RecipesPipeline:
    def __init__(self):
        self.create_connection()
        self.create_table()
    
    # creating the database mychefrecipedata.db and creating connectning to DB
    def create_connection(self):
        self.conn = sqlite3.connect("mychefrecipedata.db")
        self.curr = self.conn.cursor()
        
    # creating the table chefrecipe_tb in mychefrecipedata DB
    def create_table(self):
        self.curr.execute("""DROP TABLE IF EXISTS chefrecipe_tb""")
        self.curr.execute(""" create table chefrecipe_tb(
                         chefname text,
                         checfimg text,
                         recipename text,
                         recipelink text)""")

    def process_item(self, item, spider):
        self.store_db(item)
        return item

    # Data pushed to the table chefrecipe_tb
    def store_db(self, item):
        item = item['data']

        # moving the per page 12 entries to table chefrecipe_tb
        for i in range(0, 12):
            try:

                self.curr.execute("""insert into chefrecipe_tb(chefname, checfimg, recipename, recipelink) values(?, ?, ?, ?)""",
                                  ( item[i]['chefName'],
                                    item[i]['chefProfileImage'],
                                    item[i]['recipeName'],
                                    item[i]['recipeLink']
                                    ))
                self.conn.commit()
            except:
                pass
 
        print('Successfully Pushed to DB')


        
    
